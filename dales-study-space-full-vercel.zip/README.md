# Dale's Study Space

Full React project (deploy-ready) for Dale's Study Space.

Quick deploy (tablet-friendly):
1. Create a GitHub repo named `dales-study-space` at https://github.com/new
2. Upload the extracted contents of this ZIP to the repository (you can upload the ZIP directly; GitHub will store it as a file — better: extract then upload files).
3. On Vercel (https://vercel.com) import the GitHub project and deploy:
   - Build Command: npm run build
   - Output Directory: build
4. Rename the project in Vercel to `dalesstudyspace` to get https://dalesstudyspace.vercel.app
